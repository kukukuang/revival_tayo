<<!DOCTYPE unspecified PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<form action="test.php" method="post">
<p>이름: <input type="text" name="name" /></p>
<p>연령: <input type="text" name="age" /></p>
<p><input type="submit" /></p>


</form>
<?php
echo htmlspecialchars($_POST['name']);?> 씨 안녕하세요
당신은 <?php echo (int)$_POST['age']; ?>세입니다.

