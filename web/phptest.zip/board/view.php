<?php
	require_once("../dbconfig.php");
	$bNo = $_GET['bno'];

	if(!empty($bNo) && empty($_COOKIE['board_free_' . $bNo])) {
		$sql = 'update board_free set b_hit = b_hit + 1 where b_no = ' . $bNo;
		$result = $db->query($sql); 
		if(empty($result)) {
			?>
			<script>
				alert('오류가 발생했습니다.');
				history.back();
			</script>
			<?php 
		} else {
			setcookie('board_free_' . $bNo, TRUE, time() + (60 * 60 * 24), '/');
		}
	}
	
	$sql = 'select b_title, b_content, b_date, b_hit, b_id from board_free where b_no = ' . $bNo;
	$result = $db->query($sql);
	$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>자유게시판 | Kurien's Library</title>
	<link rel="stylesheet" href="./css/normalize.css" />
	<link rel="stylesheet" href="./css/boardView.css" />
	
</head>
<body>
	<article class="boardArticleView">
	<div id="container"> 
	<div style="background:#FFDE15;">
	<div id="top">
	<div id="top_section"></div>
	</div>
<div class="_header" id="header_nav">
<span class="header_menu"><a href="#"><img alt="" width="100" height="120" src="layout/INTRODUCE.gif" onmouseover="this.src='layout/INTRODUCE_over.gif'" onmouseout="this.src='layout/INTRODUCE.gif'" ></a></span>
<span class="header_menu"><a href="#"><img alt="" width="100" height="120" src="layout/NOTICE.gif" onmouseover="this.src='layout/NOTICE_over.gif'" onmouseout="this.src='layout/NOTICE.gif'"></a></span>
<span class="header_menu"><img alt="" width="100" height="120" src="layout/FREEBOARD.gif" onmouseover="this.src='layout/FREEBOARD_over.gif'" onmouseout="this.src='layout/FREEBOARD.gif'"></span>
<span class="header_menu"><a href="#"><img alt="" width="100" height="120" src="layout/EVENT.gif" onmouseover="this.src='layout/EVENT_over.gif'" onmouseout="this.src='layout/EVENT.gif'"></a></span>
<span class="header_menu"><img alt="" width="100" height="120" src="layout/QNA.gif" onmouseover="this.src='layout/QNA_over.gif'" onmouseout="this.src='layout/QNA.gif'"></span>
<span class="header_menu"><img alt="" width="100" height="120" src="layout/FAQ.gif" onmouseover="this.src='layout/FAQ_over.gif'" onmouseout="this.src='layout/FAQ.gif'"></span>
</div>
<div class="_section" id="header_section">
<div id="section_article">
		<center><h3>자유게시판 글쓰기</h3></center>
		<div id="boardView" style="background:#D6FA71;">
			<h3 id="boardTitle"><?php echo $row['b_title']?></h3>
			<div id="boardInfo">
				<span id="boardID">작성자: &nbsp; &nbsp;<?php echo $row['b_id']?></span>&nbsp; &nbsp; &nbsp;
				<span id="boardDate">작성일:&nbsp; &nbsp; <?php echo $row['b_date']?></span>&nbsp; &nbsp; &nbsp;
				<span id="boardHit">조회: &nbsp; &nbsp;<?php echo $row['b_hit']?></span>
			</div>
			<div class="btnSet">&nbsp; &nbsp;
				<a href="./write.php?bno=<?php echo $bNo?>">수정</a>&nbsp; &nbsp; &nbsp;
				<a href="#" onClick="window.open('./delete.php?bno=<?php echo $bNo?>','choice','scrollbars=no,width=350,height=250')">삭제</a>&nbsp; &nbsp; &nbsp;
				<a href="./">목록</a>&nbsp; &nbsp;
				 
			</div>
			
			<div id="boardContent"><?php echo $row['b_content']?></div>
			<div id="section_footer">
				<div id="boardComment">
					<?php require_once('./comment.php')?>
				</div>
			</div>
		</div>
		
		</div> <!-- section Article End  -->
<div id="section_footer"></div>
</div>

</div>
<div id="footer">
<img id="img1" src="layout/1111.PNG" height="350" width="100%">
<div id="footer_section">

<p id="introduce">school : 부천 대학교  &nbsp; &nbsp; &nbsp; &nbsp;
				major : Computer Software &nbsp; &nbsp; &nbsp;
				team name :  Revival &nbsp; &nbsp; &nbsp;
				tell : 010-1234-5824 <br>
				team member : Yun Kim Lee small_Kim 
				Project name : tayo taxi <br>because : tayo u li modoo taxi tayo honja tagi malgo u li gat e tayo </p>


</div>
</div>
</div>
	</article>
</body>
</html>