


<?php
include_once "./layout.inc"; // 레이아웃을 include 함 

$base = new Layout; // Layout class 객체를 생성

$base->link='./maincss/style.css'; // 스타일 추가
$base->content="<div id='banner_wrap'>
        <ul id='slide_banner'>
            <li>
                <a href='#'>
                    <img src='./image/banner1.jpg' alt=''>
                </a>
            </li>
            <li>
                <a href='#'>
                    <img src='./image/banner2.jpg' alt=''>
                </a>
            </li>
            <li>
                <a href='#'>
                    <img src='./image/banner3.jpg' alt=''>
                </a>
            </li>
            <li>
                <a href='#'>
                    <img src='./image/banner1.jpg' alt=''>
                </a>
            </li>
            <li>
                <a href='#'>
                    <img src='./image/banner2.jpg' alt=''>
                </a>
            </li>            
        </ul>

        <p>
            <a href='#' id='prevBtn'>
                <img src='./image/prev_btn.gif' alt='이전'>
            </a>
        </p>
        <p>
            <a href='#' id='nextBtn'>
                <img src='./image/next_btn.gif' alt='다음'>
            </a>
        </p>

    </div>"; //본문을 만듦

$base->LayoutMain(); //위의 변수들이 입력된 객체를 출력
?>

