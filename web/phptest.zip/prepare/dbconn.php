<?
    $connect=mysql_connect( "52.38.179.125", "root", "revival16") or  
        die( "SQL에 연결 되었습니다.."); 

    mysql_select_db("TAYODB",$connect);
?>
